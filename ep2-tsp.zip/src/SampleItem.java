public class SampleItem {
    public int[][] custos;
    public String fileName;

    public SampleItem(int[][] custos, String fileName) {
        this.custos = custos;
        this.fileName = fileName;
    }
}